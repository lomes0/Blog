# Handoff: AI-First Home Pane (default route, center section)

## Overview
The app is a notes/blog editor with directories, documents, and AI integration. The left sidebar (notes + projects tree) and the right icon rail already exist; the **center pane on the default route is currently blank**. This handoff specifies the chosen direction: an **AI-first blank page** — a single centered composer that both writes new content and answers questions against the user's own corpus, with suggestion chips below it and a quiet "Jump back in" recents list underneath.

Design rationale: the home route should have exactly one primary affordance. Making it the AI/composer input means "start writing" and "ask my notes" are the same gesture, and the pane never reads as an empty state because recents fill the lower third.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, **not production code to copy directly**. The task is to **recreate this design in the target codebase's existing environment** (React, Vue, Svelte, etc.) using its established component library, styling approach, and routing patterns. If the project has no established environment yet, choose the most appropriate framework and implement there.

Note: `AI Home Pane.dc.html` is authored in a component format that streams a template plus a small logic class. Read it as **markup + data**, not as a build target. All styling is inline, so every value you need is visible in the markup.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and radii below are final and were matched to the existing app shell in the reference screenshot. Recreate pixel-accurately, substituting the codebase's own primitives (Button, Input, ListItem) where they can hit these values.

## Screens / Views

### Screen: Home (default route, center pane)

**Purpose:** The user lands here with no document open. They either type a prompt (write or ask), pick a suggestion chip, or click a recent document to resume work.

**Layout**
- Root: fills the center pane between the sidebar and the right rail. In the mock the pane is `1120 × 720` with `border: 1px solid #2f3746; border-radius: 10px; background: #232a38; overflow: hidden`. **In the real app the pane is fluid** — drop the fixed size and border/radius; keep the background.
- Column flex: `display:flex; flex-direction:column`.
  - **Header bar** — `height:44px; flex-shrink:0; border-bottom:1px solid #2b3341; padding: 0 18px; display:flex; align-items:center`.
  - **Body** — `flex:1; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:26px; padding: 0 44px`. Everything is vertically and horizontally centered.

**Components (top → bottom)**

1. **Breadcrumb / context label** (header bar)
   - Text: `lomes0 / home` (workspace name + route).
   - JetBrains Mono 400, `12px`, color `#6a7689`.

2. **Mark + headline** — `display:flex; flex-direction:column; align-items:center; gap:8px`
   - Mark: `38 × 38`, `border-radius:10px`, background `#2c3446`, `border:1px solid #3d475c`, centered glyph `✦` at `18px` in `#8f9cf5`. Replace the glyph with the product's sparkle/AI icon at 18px.
   - Headline: "Write something, or ask your notes" — Inter Tight 600, `22px`, color `#e9edf4`.

3. **Composer** (primary affordance)
   - Container: `width:660px`, background `#1e2531`, `border:1px solid #3d475c`, `border-radius:12px`, `padding:16px 18px`, `display:flex; flex-direction:column; gap:14px`.
   - Focus state: border color → `#8f9cf5`. (Optional: `box-shadow: 0 0 0 3px rgba(143,156,245,0.12)`.)
   - Textarea: auto-growing, min one line, max ~6 lines then scroll. Inter Tight 400, `15px`, text `#e9edf4`, placeholder `#5f6b80`. Placeholder copy: `Summarise everything I wrote about Linux perf this year…`. Transparent background, no border, no outline, `resize:none`.
   - Footer row: `display:flex; justify-content:space-between; align-items:center`.
     - Left: two hint pills in a `display:flex; gap:8px`. Each: JetBrains Mono `11px`, color `#6a7689`, `border:1px solid #333c4c`, `border-radius:6px`, `padding:4px 8px`. Labels: `@ notes` and `/ commands`. These are affordance hints — typing `@` opens a document mention picker, `/` opens a command menu.
     - Right: submit button `30 × 30`, `border-radius:8px`, background `#8f9cf5`, glyph `↵` `14px` in `#1b2130`. Disabled when the input is empty: background `#333c4c`, glyph `#6a7689`. Hover (enabled): `#a0abf8`.

4. **Suggestion chips** — `display:flex; gap:10px; flex-wrap:wrap; justify-content:center; max-width:700px`
   - Each chip: Inter Tight 400 `13px`, color `#a6b0c2`, background `#262e3d`, `border:1px solid #333c4c`, `border-radius:20px`, `padding:8px 14px`, `cursor:pointer`.
   - Hover: background `#2e374a`, border `#4b5570`.
   - Exact copy in the mock (these should be **generated from the user's real dirs**, see State Management):
     - `Draft a post from “Linux” notes`
     - `What did I decide about EEVDF?`
     - `Find contradictions across dirs`
     - `Turn Lecture 04 into an outline`

5. **"Jump back in" list** — `width:660px; display:flex; flex-direction:column; gap:2px; margin-top:14px`
   - Section label: `JUMP BACK IN`, JetBrains Mono 400, `11px`, `letter-spacing:0.12em`, color `#697487`, `padding: 0 4px 8px`.
   - Row: `display:flex; align-items:center; gap:12px; padding:9px 4px; border-bottom:1px solid #2a3140; cursor:pointer`.
     - Doc icon glyph `▤`, `13px`, `#5f6b80` (swap for the app's file icon).
     - Title: `flex:1`, Inter Tight 400, `14px`, `#cdd5e3`.
     - Directory: JetBrains Mono `11.5px`, `#616d80`.
     - Relative time: JetBrains Mono `11.5px`, `#616d80`, `width:64px; text-align:right`.
   - Hover: row background `#262e3d`.
   - Show the 4 most recently edited documents. If the user has none (brand-new workspace), hide the entire block including the label — do not render an empty-list message.

## Interactions & Behavior
- **Submit** (`Enter`, or click ↵): send the composer text to the AI endpoint. `Shift+Enter` inserts a newline. Empty input is a no-op and the button is disabled.
- **Post-submit transition:** the home pane hands off to a result/conversation view — the composer animates from centered to pinned at the bottom of the pane (`transform`/`top` transition, `220ms`, `cubic-bezier(0.22,0.61,0.36,1)`), the headline and chips fade out (`120ms`), and the response streams in above. If the target codebase already routes AI results to a dedicated view, navigate there instead and skip the animation.
- **Chip click:** fills the composer with the chip's text and focuses the caret at the end — it does **not** auto-submit. The user should be able to edit before sending.
- **`@` in the composer:** opens an inline document/dir mention picker filtered by the text after `@`; selecting inserts a token chip that scopes the AI's retrieval to that document.
- **`/` at the start of a line:** opens a command menu (new note, new project, import, settings).
- **Recent row click:** opens that document in the editor (normal document route).
- **Autofocus:** the composer takes focus on route mount, so the user can type immediately. Do not steal focus if the user arrived via keyboard shortcut into another surface.
- **Loading:** after submit, the ↵ button becomes a spinner and the composer is read-only until the first token streams back.
- **Error:** show a single inline row directly beneath the composer — `13px`, color `#e08c8c`, background `#2f2831`, `border:1px solid #4b3a42`, `border-radius:8px`, `padding:10px 14px`, with a "Retry" text button in `#8f9cf5`. Do not use a toast.
- **Responsive:** the `660px` composer and list become `min(660px, 100% - 64px)` below ~760px of pane width. Chips wrap naturally. Below ~520px, reduce the headline to `18px` and body padding to `0 20px`.
- **Reduced motion:** honor `prefers-reduced-motion` — skip the composer transition, cut straight to the result view.

## State Management
- `promptText: string` — composer content (controlled input).
- `isSubmitting: boolean` — drives the spinner and read-only state.
- `error: string | null` — inline error copy.
- `mentionQuery: string | null` — non-null while the `@` picker is open; drives the filtered document list.
- `commandOpen: boolean` — `/` menu visibility.
- `recentDocs: { id, title, dir, updatedAt }[]` — fetch the 4 most recently updated documents on route mount; render relative times client-side ("14m", "2h", "1d", "4d").
- `suggestions: string[]` — the four chips. Generate server-side from the workspace: pick the largest/most recently active directories and the most recently edited documents, and fill templated prompts ("Draft a post from `<dir>` notes", "Turn `<doc>` into an outline"). Ship a static fallback set for empty workspaces. Cache per session so the chips don't reshuffle on every mount.

## Design Tokens

**Colors**
| Purpose | Hex |
|---|---|
| Pane background | `#232a38` |
| Pane border / divider (strong) | `#2f3746` |
| Header divider | `#2b3341` |
| Composer background (recessed) | `#1e2531` |
| Composer / mark border | `#3d475c` |
| Surface raised (chips, mark, row hover) | `#262e3d` |
| Surface raised — hover | `#2e374a` |
| Mark background | `#2c3446` |
| Hairline border (chips, pills) | `#333c4c` |
| Border hover / emphasis | `#4b5570` |
| List row divider | `#2a3140` |
| Text primary | `#e9edf4` |
| Text secondary | `#cdd5e3` |
| Text tertiary | `#a6b0c2` |
| Text muted / meta | `#6a7689`, `#616d80`, `#697487` |
| Placeholder | `#5f6b80` |
| Accent (AI, primary action, links) | `#8f9cf5` |
| Accent hover | `#a0abf8` |
| On-accent text | `#1b2130` |
| Error text / surface / border | `#e08c8c` / `#2f2831` / `#4b3a42` |

**Typography**
- UI / prose: **Inter Tight** — 400, 500, 600.
- Meta, labels, breadcrumbs, timestamps: **JetBrains Mono** — 400, 500.
- Scale in use: `22/600` headline · `15/400` composer · `14/400` list title · `13/400` chips · `12/400` breadcrumb · `11.5/400` list meta · `11/400 + 0.12em` section label.
- If the codebase already ships a mono and a UI sans, substitute them at the same sizes rather than adding two new families.

**Spacing** — 2, 4, 8, 10, 12, 14, 18, 26, 44 px. Body gap is `26px`; composer internal gap `14px`; chip gap `10px`.

**Radii** — `6px` pills · `8px` submit button, error row · `9px` cards · `10px` mark, pane · `12px` composer · `20px` chips.

**Shadows** — none. Depth is expressed with background steps (`#1e2531` recessed → `#232a38` base → `#262e3d` raised) and 1px borders. Do not add drop shadows.

**Sizing** — composer and recents column: `660px`. Chip row max width: `700px`. Mark and submit button: `38px` / `30px` squares. Header bar: `44px`.

## Assets
No image assets. Two glyphs are placeholders for real icons:
- `✦` — the AI/sparkle mark (38px container, 18px glyph). The app's right rail already uses a sparkle icon; reuse that.
- `▤` — document icon in recents. Reuse the file icon already used in the left sidebar's NOTES list.

Fonts are loaded from Google Fonts in the prototype; self-host or use the codebase's existing font pipeline.

## Files
- `AI Home Pane.dc.html` — the chosen design, isolated. This is the spec surface; open it in a browser.
- `Home Pane Ideas.dc.html` — the full exploration (three directions side by side: workbench, AI-first, briefing dashboard). Included for context on what was rejected and why; the AI-first option is `1b`.
- `support.js` — runtime needed by both HTML files. Keep it alongside them; nothing in it is part of the design.
