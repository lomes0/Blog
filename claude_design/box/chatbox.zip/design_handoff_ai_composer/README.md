# Handoff: AI Chat Composer (option 1a — "Refined original")

## Overview
A refinement of an existing AI chat input box ("composer") for a desktop web app. Same anatomy as the current shipping UI — multiline text field on top, a single control row beneath — but with corrected craft: a real icon toolbar, an optically aligned model picker, a hairline border instead of a heavy colored ring, and tighter vertical rhythm. Keyboard hints moved outside the box so the container holds only interactive controls.

Supports: file/image attachments, slash commands, @-mentions, voice input, model selection, send, and stop generation.

## About the Design Files
`Composer.dc.html` in this bundle is a **design reference created in HTML** — a working prototype that shows the intended look and behavior. It is **not production code to copy**. The task is to **recreate this design in the target codebase's existing environment** (React, Vue, Svelte, SwiftUI, native, etc.) using that codebase's established component primitives, styling approach, and icon library. If no environment exists yet, pick the framework most appropriate for the project and implement there.

Open the file directly in a browser to interact with it: type in the field, open the model menu, press the send button to see the generating/stop state.

## Fidelity
**High-fidelity.** All colors, type sizes, radii, spacing, and shadows below are final and should be matched exactly. Interaction behavior (menu, send/stop swap) is also final. Icons are inline SVG stand-ins — substitute the codebase's icon set at the same optical sizes.

## Screens / Views

### Composer (single view, all states)
**Purpose:** the user composes a message, attaches context, picks a model, and sends; while a response streams they can stop it.

**Layout**
- Outer column: `display: flex; flex-direction: column; gap: 14px`. Width 760px max (fluid below that); in the real app it should match the chat thread's content column width.
- **Gradient hairline wrapper:** `border-radius: 18px; padding: 1px; background: linear-gradient(#3d4058, #33364a)`. This is a 1px top-lit border, not a visible ring. Implement as a 1px-padded gradient wrapper (or `border-image` / pseudo-element) — a flat 1px border loses the top-light effect.
- **Surface:** `background: #292d3e; border-radius: 17px; padding: 14px 14px 10px; display: flex; flex-direction: column; gap: 10px; box-shadow: 0 18px 40px -24px #0b0d17`. Note asymmetric padding — bottom is 10px because the 32px icon buttons carry their own optical padding.
- **Text area block:** wrapped in `padding: 4px 6px 0` so the caret aligns optically with the toolbar icons' glyphs rather than their hit boxes.
- **Control row:** `display: flex; align-items: center; gap: 6px`, with a `flex: 1` spacer between the model picker and the right-hand group.

**Components**

1. **Textarea**
   - `rows="2"`, auto-grow to `max-height: 180px` then scroll.
   - Font: DM Sans 16px / line-height 1.55 / `letter-spacing: -0.005em`, color `#e2e6f0`.
   - Placeholder: `Ask anything, or type / for commands`, color `#6f7690`.
   - No border, no outline, no resize handle, transparent background.

2. **Left icon buttons** — Attach (plus glyph), Slash commands (`/`), Mention (`@`)
   - 32×32px, `border-radius: 9px`, no border, transparent background.
   - Icon color `#9098b3`; stroke SVGs at 17×17 with `stroke-width: 1.8`, round caps.
   - `/` and `@` are JetBrains Mono 15px glyphs, not SVG.
   - **Hover:** `background: #333750; color: #dfe4f1`.
   - `title` attributes provide tooltips; real implementation should use the app's tooltip component with labels "Attach files", "Slash commands", "Mention a file", "Voice input".

3. **Divider** — 1px × 20px, `#3b3f57`, `margin: 0 4px`. Separates content tools from the model context.

4. **Model picker button**
   - Height 32px, `padding: 0 9px 0 10px` (asymmetric — the chevron needs less), `border-radius: 9px`, transparent, `gap: 7px`.
   - Status dot: 7px circle, `#f0794f`, with `box-shadow: 0 0 0 3px #f0794f26` as a soft halo.
   - Label: DM Sans 13.5px / weight 500 / `#b6bdd4`.
   - Chevron: 12×12 SVG, `stroke-width: 2.2`, `opacity: 0.6`.
   - **Hover:** `background: #333750; color: #eef1f8`.

5. **Model menu** (popover, opens upward)
   - Anchored `position: absolute; bottom: 40px; left: 0`. Width 268px.
   - `background: #2f3348; border: 1px solid #414560; border-radius: 13px; padding: 6px; box-shadow: 0 24px 48px -16px #0a0c14cc; z-index: 5`.
   - Rows: full width, `padding: 9px 10px`, `border-radius: 9px`, `gap: 10px`. 7px `#f0794f` dot + two-line label stack (`gap: 2px`): name DM Sans 13.5px/500 `#dfe4f1`, note 12px `#8b93ad`.
   - **Row hover:** `background: #3a3f59`.
   - Items: `Claude Sonnet 5 / Balanced speed and depth`, `Claude Opus 4.6 / Deepest reasoning`, `Claude Haiku 4.5 / Fastest, cheapest`. Replace with the app's real model list.
   - Production must add: click-outside and Escape to dismiss, arrow-key roving focus, `role="menu"` / `role="menuitemradio"` with `aria-checked` on the active model, focus return to the trigger on close.

6. **Voice input button** — same spec as the left icon buttons (32×32, `#9098b3`, hover `#333750`). Sits at the right end of the row, immediately before send.

7. **Send button** (idle state)
   - 34×34px — deliberately 2px larger than the secondary icon buttons so it reads as primary.
   - `border-radius: 10px; background: #6a6bf2; color: #fff; box-shadow: 0 6px 16px -6px #6a6bf2cc`.
   - Icon: 16×16 up-arrow, `stroke-width: 2`, round caps/joins.
   - **Hover:** `background: #7b7cf6`.
   - Production: disable (`opacity: 0.45`, `cursor: default`, no shadow) when the field is empty and there are no attachments.

8. **Stop button** (generating state) — replaces send in place, same 34×34 footprint so the row doesn't shift. `background: #3b4059; color: #e6eaf4`, no shadow, 13×13 filled square with `rx: 2.5`. **Hover:** `#474d6b`.

9. **Keyboard hint row** — outside the box, `padding: 0 4px`, `gap: 16px`, 12px `#767d99`. Key glyphs (`↩`, `⇧↩`) in JetBrains Mono `#9aa2bd`. Content: "↩ send", "⇧↩ new line".

**Attachment chips (not in this option's mock, needed in production)**
When files are attached, insert a chip row above the textarea inside the surface, `gap: 8px`. Chip spec (borrowed from option 1c): height 30px, `padding: 0 11px 0 8px`, `border-radius: 8px`, `background: #353a51`, 12.5px `#ccd2e3` label, 14px file icon stroked `#f0794f`, 12px × dismiss stroked `#8b93ad`.

## Interactions & Behavior
- **Typing:** field auto-grows from 2 rows to a 180px cap, then scrolls internally. The whole composer grows downward; the control row stays pinned to the bottom.
- **Enter** sends; **Shift+Enter** inserts a newline. Enter must not send while an IME composition is active.
- **Model picker:** click toggles the popover upward. Selecting an item sets the model and closes.
- **Send:** clears the field and enters the generating state. In the prototype this auto-resolves after 3200ms; in production it's driven by the streaming response lifecycle.
- **Stop:** returns to idle immediately.
- **Hover transitions:** background/color on icon buttons, ~120ms ease-out. Nothing else animates — no scale, no lift.
- **Focus:** the mock relies on default focus rings; production should draw a 2px `#6a6bf2` focus ring at 2px offset on every button, and the composer surface should show a subtle focus-within treatment (recommended: shift the gradient wrapper's top stop toward `#4d5170`).
- **Responsive:** desktop-first. Below ~640px the left tool trio should collapse behind a single "+" menu; everything else holds.

## State Management
| State | Type | Purpose / transitions |
| --- | --- | --- |
| `text` | string | Field contents. Cleared on send. |
| `menu` | boolean | Model popover open. Toggled by trigger; false on select, click-outside, Escape. |
| `busy` | boolean | Generating. True on send, false on stop or stream end. Controls send↔stop swap. |
| `model` | string | Selected model id/name. |
| `attachments` | array | Production only — drives the chip row and keeps send enabled when text is empty. |

Data needs: the model list (id, display name, one-line note), the streaming message endpoint, an upload endpoint for attachments, and command/mention sources for `/` and `@` autocomplete (out of scope for this mock).

## Design Tokens

**Colors**
| Token | Hex | Use |
| --- | --- | --- |
| bg/page | `#1b1e2b` | Page behind the composer |
| bg/surface | `#292d3e` | Composer surface |
| bg/popover | `#2f3348` | Model menu |
| bg/hover | `#333750` | Icon button hover |
| bg/hover-strong | `#3a3f59` | Menu row hover |
| bg/neutral-action | `#3b4059` | Stop button (hover `#474d6b`) |
| border/gradient-top | `#3d4058` | Hairline wrapper top stop |
| border/gradient-bottom | `#33364a` | Hairline wrapper bottom stop |
| border/popover | `#414560` | Menu border |
| divider | `#3b3f57` | Toolbar divider |
| text/primary | `#e2e6f0` | Typed text |
| text/on-popover | `#dfe4f1` | Menu labels, icon hover |
| text/secondary | `#b6bdd4` | Model label |
| text/tertiary | `#9098b3` | Idle icons |
| text/muted | `#8b93ad` | Menu notes |
| text/hint | `#767d99` | Keyboard hints |
| text/placeholder | `#6f7690` | Placeholder |
| accent/primary | `#6a6bf2` | Send, focus ring (hover `#7b7cf6`) |
| accent/model | `#f0794f` | Model status dot, file icon |
| link | `#a5a5fb` (hover `#c4c4fd`) | Inline links |

**Typography** — DM Sans (400/500/600) for UI; JetBrains Mono (400/500) for key glyphs, `/`, `@`, counters.
Scale: 16px/1.55 input · 13.5px/500 model label + menu name · 12.5px chip · 12px menu note + hints · 11px/`0.14em` uppercase mono eyebrow.

**Spacing** — 2 · 4 · 6 · 8 · 9 · 10 · 14 · 16 px. Control row gap 6px; surface gap 10px; outer gap 14px.

**Radii** — 18px wrapper · 17px surface · 13px popover · 10px send/stop · 9px icon buttons + menu rows · 8px chips · 99px dots.

**Shadows**
- surface: `0 18px 40px -24px #0b0d17`
- popover: `0 24px 48px -16px #0a0c14cc`
- send: `0 6px 16px -6px #6a6bf2cc`
- model dot halo: `0 0 0 3px #f0794f26`

## Assets
No image assets. Icons are inline stroke SVGs authored for this mock (plus, paperclip, microphone, chevron-down, up-arrow, filled square, file, x) — swap for the codebase's icon library at 17px (secondary), 16px (send), 12px (chevron), 13px (stop). Fonts load from Google Fonts; self-host or map to the codebase's existing families if it already has a sans/mono pair.

## Files
- `Composer.dc.html` — option 1a in isolation, all states live. **Primary reference.**
- `../Chatbox.dc.html` — the exploration file with all three directions (1a, 1b "Quiet pill", 1c "Workbench tray") side by side, for context on what was considered.
